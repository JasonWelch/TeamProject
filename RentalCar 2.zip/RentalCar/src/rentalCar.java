
import java.util.ArrayList;
import CarsAndCarRenters.Car;
import CarsAndCarRenters.CarRenter;
import CarsAndCarRenters.SmallCar;
import CarsAndCarRenters.BigCar;


public class rentalCar {

    public static void main(String[] args) {
    	ArrayList<Car> carArray = new ArrayList();
    	// Sets values to each of three car renters
        CarRenter renter1 = new CarRenter("Amanda", "IL12345", "456 Fake Street");
        CarRenter renter2 = new CarRenter("Thom", "IN56789", "986 Lost Ave");
        CarRenter renter3 = new CarRenter("Tyler", "WI24680", "244 Closed Place");
        
        //Sets values to each of three cars
        Car car1 = new SmallCar("VW12345","VW", "Beettle", 2013, 15000.00, renter1, "coupe");
        Car car2 = new SmallCar("BX56789", "BMW", "335D", 2011, 21000.00, renter2, "sedan");
        Car car3 = new BigCar("FD24578", "Ford", "F150", 2021, 5600.90, renter3, "truck");
       
       //Store Three cars into carArray
        carArray.add(car1);
        carArray.add(car2);
        carArray.add(car3);
    
    //Set new int
    int counter;
    // For loop to run 3 times to Print stored array
    for (counter = 0; counter < 3; counter++){
        System.out.print(carArray.get(counter));
    }
    }
    	
}

