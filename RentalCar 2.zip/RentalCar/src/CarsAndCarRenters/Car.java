
package CarsAndCarRenters;



public abstract class Car {
    
    //Creates new variables for car information and somewhere to put owner's data
	String carID;
    String carMake;
    String carModel;
    int carYear;
    double carPrice;
    CarRenter carOwnerData;
    
    //Creates Car object to store multiple variables
    public Car (String receivedCarID, String receivedCarMake, String receivedCarModel, int receivedCarYear, double receivedCarPrice, CarRenter receivedOwnerData){
        this.carID = receivedCarID;
    	this.carMake = receivedCarMake;
        this.carModel = receivedCarModel;
        this.carYear = receivedCarYear;
        this.carPrice = receivedCarPrice;
        this.carOwnerData = receivedOwnerData;
        
                
    }
    
    //initializes Car to have null values
     public Car (){
    	this.carID = "";
        this.carMake = "";
        this.carModel = "";
        this.carYear = 0;
        this.carPrice = 0;
        this.carOwnerData = new CarRenter();
     }


//establishes gets for car data to be used by UseCar
    public String GetCarID() {
    	return this.carID+"\n";
    }
    
    public String GetCarMake(){
        return this.carMake+"\n";
    }
    
    public String GetCarModel(){
        return this.carModel+"\n";
    }
    
    public int GetCarYear(){
        return this.carYear;
    }
    
    public double GetCarPrice(){
        return this.carPrice;
    }
    
//Establishes sets for car data to be used by UseCar
    public void UpdatedCarID(String updatedCarID) {
    	this.carID = updatedCarID;
    }
    public void UpdatedCarMake(String updatedCarMake){
        this.carMake = updatedCarMake;
    }
    
    public void UpdatedCarModel(String updatedCarModel){
        this.carModel = updatedCarModel;
    }
    
    public void UpdatedCarYear(int updatedCarYear){
        this.carYear = updatedCarYear;
    }
    
    public void UpdatedCarPrice(double updatedCarPrice){
        this.carPrice = updatedCarPrice;
    }
    
    //Establishes an abstract toString method to be used by SmallCar and BigCar
    public abstract String toString();
    
    
}
