
import java.util.ArrayList;
import CarsAndCarRenters.Car;
import CarsAndCarRenters.CarRenter;
import CarsAndCarRenters.SmallCar;
import CarsAndCarRenters.BigCar;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.FlowPane;
import java.text.DecimalFormat;


public class rentalCar extends Application{

	public static void main(String[] args) {
		launch(args);
	}

	public void start(Stage primaryStage) {
		// Create a scene by calling the method above and place it in the stage
		Scene scene = new Scene(getPane(), 1000, 1000);
		primaryStage.setTitle("Rental Car System"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}
	protected BorderPane getPane() {

		final ArrayList<Car> carArray = new ArrayList<>(); //create array list that holds all accounts made 

		//Declare the UI Controls (Labels, Buttons, TextFields, etc.) needed for this GUI 
		Label lblRenterName = new Label("Renter's Name: ");//labels needed for GUI
		Label lblRenterID = new Label("Renter's ID: ");
		Label lblRenterAddy = new Label("Renter's Address: ");
		Label lblCarID = new Label("Car ID: ");
		Label lblCarMake = new Label("Car Make: ");
		Label lblCarModel = new Label("Car Model: ");
		Label lblCarYear = new Label("Car Year: ");
		Label lblCarPrice = new Label("Car Price: ");
		Label lblCarType = new Label("Car Type: ");


		Button reserveSmCrBtn = new Button("Reserve Small Car");//buttons needed for GUI
		Button reserveBgCrBtn = new Button("Reserve Big Car");
		Button rtrnCrBtn = new Button("Return Car");
		Button displayRntlBtn = new Button("Display Rental Info");

		final TextField txtName = new TextField(); //textfields and text areas needed for this GUI
		final TextField txtRenterID = new TextField();
		final TextField txtRenterAddy = new TextField();
		final TextField txtCarID = new TextField(); 
		final TextField txtCarMake= new TextField();
		final TextField txtCarModel = new TextField();
		final TextField txtCarYear = new TextField(); 
		final TextField txtCarPrice = new TextField();
		final TextField txtCarType = new TextField();
		final TextArea displayArea = new TextArea();
		displayArea.setPrefRowCount(7);
		displayArea.setPrefColumnCount(45);

		MenuBar menuBar = new MenuBar(); //menu and menu items needed for this GUI
		menuBar.setPrefWidth(1000);  
		Menu fileMenu = new Menu("File");
		MenuItem exitMenuOption = new MenuItem("Exit");
		fileMenu.getItems().addAll(exitMenuOption);

		//gridpane for account creation
		GridPane centerPane = new GridPane();
		//Sets the top, right, bottom, and left padding around the region's content
		centerPane.setPadding(new Insets(0,15,0,15));
		//Set the amount of horizontal space between each node
		centerPane.setHgap(5);
		//Set the amount of vertical space between each node
		centerPane.setVgap(5); 
		centerPane.add(lblRenterName, 0, 0);
		centerPane.add(txtName, 1, 0);
		centerPane.add(lblRenterID, 0, 1);
		centerPane.add(txtRenterID, 1, 1);
		centerPane.add(lblRenterAddy, 0, 2);
		centerPane.add(txtRenterAddy, 1, 2);
		centerPane.add(lblCarID, 0, 3);
		centerPane.add(txtCarID, 1, 3);
		centerPane.add(lblCarMake, 0, 4);
		centerPane.add(txtCarMake, 1, 4);
		centerPane.add(lblCarModel, 0, 5);
		centerPane.add(txtCarModel, 1, 5);
		centerPane.add(lblCarYear, 0, 6);
		centerPane.add(txtCarYear, 1, 6);
		centerPane.add(lblCarPrice, 0, 7);
		centerPane.add(txtCarPrice, 1, 7);
		centerPane.add(lblCarType, 0, 8);
		centerPane.add(txtCarType, 1, 8);
		centerPane.setAlignment(Pos.CENTER);

		//gridpane for options to adjust accounts
		FlowPane bottomPane = new FlowPane();
		bottomPane.setPadding(new Insets(0,0,5,0));
		bottomPane.setHgap(5);
		bottomPane.setVgap(20);
		bottomPane.getChildren().addAll(displayArea,reserveSmCrBtn, reserveBgCrBtn, rtrnCrBtn, displayRntlBtn);
		bottomPane.setAlignment(Pos.CENTER);

		//border pane that holds all other panes
		BorderPane mainPane = new BorderPane();
		menuBar.getMenus().addAll(fileMenu);
		mainPane.setTop(menuBar);
		mainPane.setCenter(centerPane);
		mainPane.setBottom(bottomPane);

		reserveSmCrBtn.setOnAction(new EventHandler<ActionEvent>() { //reserves small cars
			public void handle(ActionEvent e) {
				try{
					String Name = txtName.getText();
					String RenterID = txtRenterID.getText();
					String Address = txtRenterAddy.getText();
					int CarID = Integer.parseInt(txtCarID.getText());
					String Make = txtCarMake.getText();
					String Model = txtCarModel.getText();
					String SmCrType = txtCarType.getText();
					int CarYear = Integer.parseInt(txtCarYear.getText());
					double CarPrice = Double.parseDouble(txtCarPrice.getText());
					CarRenter renter = new CarRenter(Name, RenterID, Address);
					SmallCar smCar = new SmallCar(CarID, Make, Model, CarYear, CarPrice, renter,
							SmCrType);

					int x = 0;
					int x1 = 0;
					for(int i1 = 0; i1 < carArray.size(); i1++){
						if(RenterID == carArray.get(i1).carOwnerData.getOwnerID() && 
								Address.equals(carArray.get(i1).carOwnerData.getOwnerAddress()) && 
								Name.equals(carArray.get(i1).carOwnerData.getOwnerName()) == false){
							x1++;
						}
					}
					if(x1 == 0){
						for(int i = 0; i < carArray.size(); i++){
							if(carArray.get(i).getCarID().equals(CarID)){
								x++;
							}
						}
						if(x == 0){
							carArray.add(smCar);
							displayArea.setText("You have reserved this small rental car! \nName: "
									+ Name + "\nRenter ID: " + RenterID + "\nCar ID: " + CarID + "\nMake: " + Make + "\nModel: " 
									+ Model + "\nYear: " + CarYear + "\nPrice: " + CarPrice);
							txtName.setText("");
							txtCarID.setText("");
							txtRenterID.setText("");
							txtCarMake.setText("");
							txtCarModel.setText("");
							txtCarYear.setText("");
							txtCarPrice.setText("");
						}
						else if(x != 0){
							displayArea.setText("This Car has already been reserved! This reservation could not be created. ");
						}
					}
					if(x1 > 0){
						displayArea.setText("Reservation could not be created, Renter ID already exists.");
					}
				}
				catch(NumberFormatException exception){
					displayArea.setText("Please only enter integers for renter ID and car ID.");
				}
			}
		});

		reserveBgCrBtn.setOnAction(new EventHandler<ActionEvent>() { //reserves big cars
			public void handle(ActionEvent e) {
				try{
					String Name = txtName.getText();
					String RenterID = txtRenterID.getText();
					String Address = txtRenterAddy.getText();
					int CarID = Integer.parseInt(txtCarID.getText());
					String Make = txtCarMake.getText();
					String Model = txtCarModel.getText();
					String BgCrType = txtCarType.getText();
					int CarYear = Integer.parseInt(txtCarYear.getText());
					double CarPrice = Double.parseDouble(txtCarPrice.getText());
					CarRenter renter = new CarRenter(Name, RenterID, Address);
					BigCar bgCar = new BigCar(CarID, Make, Model, CarYear, CarPrice, renter,
							BgCrType);

					int x = 0;
					int x1 = 0;
					for(int i1 = 0; i1 < carArray.size(); i1++){
						if(RenterID == carArray.get(i1).carOwnerData.getOwnerID() && 
								Address.equals(carArray.get(i1).carOwnerData.getOwnerAddress()) && 
								Name.equals(carArray.get(i1).carOwnerData.getOwnerName()) == false){
							x1++;
						}
					}
					if(x1 == 0){
						for(int i = 0; i < carArray.size(); i++){
							if(carArray.get(i).getCarID().equals(CarID)){
								x++;
							}
						}
						if(x == 0){
							carArray.add(bgCar);
							displayArea.setText("You have reserved this big rental car! \nName: "
									+ Name + "\nRenter ID: " + RenterID + "\nCar ID: " + CarID + "\nMake: " + Make + "\nModel: " 
									+ Model + "\nYear: " + CarYear + "\nPrice: " + CarPrice);
							txtName.setText("");
							txtCarID.setText("");
							txtRenterID.setText("");
							txtCarMake.setText("");
							txtCarModel.setText("");
							txtCarYear.setText("");
							txtCarPrice.setText("");
						}
						else if(x != 0){
							displayArea.setText("This Car has already been reserved! This reservation could not be created. ");
						}
					}
					if(x1 > 0){
						displayArea.setText("Reservation could not be created, Renter ID already exists.");
					}
				}
				catch(NumberFormatException exception){
					displayArea.setText("Please only enter integers for renter ID and car ID.");
				}
			}
		});

		displayRntlBtn.setOnAction(new EventHandler<ActionEvent>() { //handles the display button and creates a new stage

			public void handle(ActionEvent e) {
				Label displayRental = new Label("Enter rental ID to display rental info: ");
				final TextField displayRntl = new TextField();
				Button displayRntlBtn= new Button("Display Rental Info");
				displayRntlBtn.setPrefWidth(175);
				Button btnCancel = new Button("Cancel");
				btnCancel.setPrefWidth(175);

				GridPane displayPane = new GridPane();
				displayPane.add(displayRental, 0, 0);
				displayPane.add(displayRntl, 1, 0);
				displayPane.add(displayRntlBtn, 0, 1);
				displayPane.add(btnCancel, 1, 1);
				displayPane.setHgap(10);
				displayPane.setVgap(10);
				displayPane.setAlignment(Pos.CENTER);

				Scene displayScene = new Scene(displayPane, 400, 150);

				final Stage displayWindow = new Stage();
				displayWindow.setTitle("Display Rental Info");
				displayWindow.setScene(displayScene);
				displayWindow.show();

				btnCancel.setOnAction(new EventHandler<ActionEvent>(){

					public void handle(ActionEvent event) {
						displayArea.setText("Display information cancelled.");
						displayWindow.close();
					}
				});
				displayRntlBtn.setOnAction(new EventHandler<ActionEvent>() { //handles the display button and displays the rental reservation information in the text area

					public void handle(ActionEvent event) {

						DecimalFormat df = new DecimalFormat("0.00"); //formatting for dollars

						try{
							int statistics = 0;
							if(carArray.isEmpty() == true){ //displays this message if there are no accounts in the array list
								displayArea.setText("There are no active rentals in this system.\n");
							}

							if (carArray.isEmpty() == false){ 
								int accountStatistics = Integer.parseInt(displayRntl.getText());
								for(int i = 0; i < carArray.size(); i++){
									if(carArray.get(i).getCarID().equals(accountStatistics)){
										displayArea.setText("Details of rental ID: " + carArray.get(i).getCarID() + 
												"\n========================"  + 
												"\nRenter ID: " + carArray.get(i).carOwnerData.getOwnerID() + 
												"\nRenter Name: " + carArray.get(i).carOwnerData.getOwnerName() + 
												"\nPrice: $" + df.format(carArray.get(i).getCarPrice()));
										statistics++;
										displayWindow.close();
										break;
									}
								}
							}

							if (statistics == 0){ //displays error message if car ID is incorrect
								displayArea.setText("Please enter a correct Car ID.");
								displayWindow.close();
							}
						}
						catch(NumberFormatException exception){ //displays message if anything other than integers are inputted
							displayArea.setText("Please only enter integers for Car ID numbers.");
							displayWindow.close();
						}

					}
				});
			}
		});

		rtrnCrBtn.setOnAction(new EventHandler<ActionEvent>() { //handles the return button and creates a new stage

			public void handle(ActionEvent e) {
				Label returnRental = new Label("Enter Car ID to return: ");
				final TextField returnRntl = new TextField();
				Button rtrnCrBtn= new Button("Return");
				rtrnCrBtn.setPrefWidth(175);
				Button btnCancel = new Button("Cancel");
				btnCancel.setPrefWidth(175);

				GridPane removePane = new GridPane();
				removePane.add(returnRental, 0, 0);
				removePane.add(returnRntl, 1, 0);
				removePane.add(rtrnCrBtn, 0, 1);
				removePane.add(btnCancel, 1, 1);
				removePane.setHgap(10);
				removePane.setVgap(10);
				removePane.setAlignment(Pos.CENTER);

				Scene removeScene = new Scene(removePane, 400, 150);

				final Stage removeWindow = new Stage();
				removeWindow.setTitle("Return Rental");
				removeWindow.setScene(removeScene);
				removeWindow.show();

				btnCancel.setOnAction(new EventHandler<ActionEvent>(){ //handles the cancel button on the new stage

					public void handle(ActionEvent event) {
						displayArea.setText("Return cancelled.");
						removeWindow.close();
					}
				});

				rtrnCrBtn.setOnAction(new EventHandler<ActionEvent>() { //handles the return button and removes the account from the array list

					public void handle(ActionEvent event) {

						try{
							int remove = 0;
							int rentalReturn = Integer.parseInt(returnRntl.getText());
							for(int i = 0; i < carArray.size(); i++){ //this removes the object from the array list if the car ID numbers match
								if(carArray.get(i).getCarID().equals(rentalReturn)){
									displayArea.setText("Car" + carArray.get(i).getCarID() + " has been successfully returned!");
									carArray.remove(i);
									remove++;
									removeWindow.close();
									break;
								}
							} 

							if (remove == 0){ //displays error message if account number is incorrect
								displayArea.setText("Could not return car. Please enter a correct Car ID.");
								removeWindow.close();
							}
						}
						catch(NumberFormatException exception){ //displays error message if anything other than integers are inputted
							displayArea.setText("Could not return car. Please only enter Car ID numbers.");
							removeWindow.close();
						}


					}
				});


			}
		});

		exitMenuOption.setOnAction(new EventHandler<ActionEvent>() { //handles the exit menu button

			public void handle(ActionEvent e) {
				Platform.exit();
			}
		});

		return mainPane;
	}

}




