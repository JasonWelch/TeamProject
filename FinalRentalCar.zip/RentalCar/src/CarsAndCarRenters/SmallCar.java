package CarsAndCarRenters;

public class SmallCar extends Car {
	
	private String SmallCarType;//Instance Variable
	
	public SmallCar(int receivedCarID, String receivedCarMake, String receivedCarModel, int receivedCarYear, double receivedCarPrice, 
			CarRenter receivedOwnerData, String SmCrTp) {
		super(receivedCarID, receivedCarMake, receivedCarModel, receivedCarYear, receivedCarPrice, 
				receivedOwnerData);
		this.SmallCarType = SmCrTp;
	}
	// Returns Small Car Type
	public String getSmCrTp() {
		return SmallCarType;
	}
	// Sets Small Car Type
	public void setSmCrTp(String SmCrTp) {
		this.SmallCarType = SmCrTp;
	}
	
	//Establishes toString to be used by SmallCar to print all Car info and Calls to Owner Data to return those values
	public String toString(){
        String carInfo;
        carInfo = "\nCar ID: " + this.carID + "\nSmall Car Type: " + this.SmallCarType + "\nCar Make: " + this.carMake + "\nCar Model: " +this.carModel + "\nCar Year: " 
        + this.carYear + "\nCar Price: $" +this.carPrice +"\n" +this.carOwnerData.toString();
        return carInfo;
    }
		
		
}
