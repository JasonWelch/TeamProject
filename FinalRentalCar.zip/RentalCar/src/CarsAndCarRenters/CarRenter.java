
package CarsAndCarRenters;


public class CarRenter {
    
    //Creates new variables
    private String ownerName;
    private String ownerID;
    private String ownerAddress;
    
    //Creates CarOwner object to store owner data
    public CarRenter(String receivedOwnerName, String receivedOwnerID, String receivedOwnerAddress){
        this.ownerName = receivedOwnerName;
        this.ownerID = receivedOwnerID;
        this.ownerAddress = receivedOwnerAddress;
    }
    
    //Initializes CarOwner to have Null values
    public CarRenter(){
        this.ownerName = "";
        this.ownerID = "";
        this.ownerAddress = "";
    }
//establishes gets for owner data to be used by UseCar
    public String getOwnerName(){
        return this.ownerName+"\n";
    }
    
    public String getOwnerID() {
    	return this.ownerID+"\n";
    }
    
    public String getOwnerAddress(){
        return this.ownerAddress+"\n";
    }
    
//establishes sets for owner data to be used by UseCar    
    public void setOwnerName(String updatedOwnerName){
        this.ownerName = updatedOwnerName;
    }
    
    public void setOwnerID(String updatedOwnerID) {
    	this.ownerID = updatedOwnerID;
    }
    
    public void setOwnerAddress(String updatedOwnerAddress){
        this.ownerAddress = updatedOwnerAddress;
    }
    
//Establishes toString to be used by UseCar to print all owner info and to be called by car    
    public String toString(){
        String ownerInfo;
        ownerInfo ="Owner Name: " + this.ownerName + "\n" + "Owner ID: " + this.ownerID + "\n" + "Owner Address: " 
        + this.ownerAddress + "\n";
        return ownerInfo;
    }
}
