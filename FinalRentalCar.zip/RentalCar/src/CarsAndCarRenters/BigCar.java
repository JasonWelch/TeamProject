package CarsAndCarRenters;

public class BigCar extends Car {
	
private String BigCarType;// instance variable
	
	public BigCar(int receivedCarID, String receivedCarMake, String receivedCarModel, int receivedCarYear, double receivedCarPrice, 
			CarRenter receivedOwnerData, String BgCrTp) {
		super(receivedCarID, receivedCarMake, receivedCarModel, receivedCarYear, receivedCarPrice, 
				receivedOwnerData);
		this.BigCarType = BgCrTp;
	}
	// Returns Big Car Type
	public String getBgCrTp() {
		return BigCarType;
	}
	// Sets Big Car Type
	public void setBgCrTp(String BgCrTp) {
		this.BigCarType = BgCrTp;
	}
	
	//Establishes toString to be used by BigCar to print all Car info and Calls to Owner Data to return those values
	public String toString(){
        String carInfo;
        carInfo = "\nCar ID: " + this.carID + "\nBig Car Type: " + this.BigCarType + "\nCar Make: " + this.carMake + "\nCar Model: " +this.carModel + "\nCar Year: " 
        + this.carYear + "\nCar Price: $" +this.carPrice +"\n" +this.carOwnerData.toString();
        return carInfo;
    }

}
