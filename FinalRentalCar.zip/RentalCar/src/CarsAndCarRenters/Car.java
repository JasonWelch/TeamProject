
package CarsAndCarRenters;



public abstract class Car {
    
    //Creates new variables for car information and somewhere to put owner's data
	int carID;
    String carMake;
    String carModel;
    int carYear;
    double carPrice;
    public CarRenter carOwnerData;
    
    //Creates Car object to store multiple variables
    public Car (int receivedCarID, String receivedCarMake, String receivedCarModel, int receivedCarYear, double receivedCarPrice, CarRenter receivedOwnerData){
        this.carID = receivedCarID;
    	this.carMake = receivedCarMake;
        this.carModel = receivedCarModel;
        this.carYear = receivedCarYear;
        this.carPrice = receivedCarPrice;
        this.carOwnerData = receivedOwnerData;
        
                
    }
    
    //initializes Car to have null values
     public Car (){
    	this.carID = 0;
        this.carMake = "";
        this.carModel = "";
        this.carYear = 0;
        this.carPrice = 0;
        this.carOwnerData = new CarRenter();
     }


//establishes gets for car data to be used by UseCar
    public String getCarID() {
    	return this.carID+"\n";
    }
    
    public String getCarMake(){
        return this.carMake+"\n";
    }
    
    public String getCarModel(){
        return this.carModel+"\n";
    }
    
    public int getCarYear(){
        return this.carYear;
    }
    
    public double getCarPrice(){
        return this.carPrice;
    }
    
//Establishes sets for car data to be used by UseCar
    public void updatedCarID(int updatedCarID) {
    	this.carID = updatedCarID;
    }
    public void updatedCarMake(String updatedCarMake){
        this.carMake = updatedCarMake;
    }
    
    public void updatedCarModel(String updatedCarModel){
        this.carModel = updatedCarModel;
    }
    
    public void updatedCarYear(int updatedCarYear){
        this.carYear = updatedCarYear;
    }
    
    public void updatedCarPrice(double updatedCarPrice){
        this.carPrice = updatedCarPrice;
    }
    
    //Establishes an abstract toString method to be used by SmallCar and BigCar
    public abstract String toString();
    
    
}
